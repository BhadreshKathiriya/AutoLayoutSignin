//
//  DynTableViewCell.m
//  TableViewCellDynamicHeight
//
//  Created by Pro Start Me on 9/8/16.
//  Copyright © 2016 Pro Start Me. All rights reserved.
//

#import "DynTableViewCell.h"

@implementation DynTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
