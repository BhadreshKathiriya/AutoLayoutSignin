//
//  ViewController.m
//  TableViewCellDynamicHeight
//
//  Created by Pro Start Me on 9/8/16.
//  Copyright © 2016 Pro Start Me. All rights reserved.
//

#import "ViewController.h"
#import "DynTableViewCell.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.tblUser.estimatedRowHeight = 200;
    self.tblUser.rowHeight = UITableViewAutomaticDimension;
    
    arrUser = [[NSMutableArray alloc]init];
    
    NSMutableDictionary *dictTemp1 = [[NSMutableDictionary alloc]init];
    [dictTemp1 setObject:@"http://www.freeiconspng.com/uploads/google-drive-icon-26.png" forKey:@"url"];
    [dictTemp1 setObject:@"Name : Ankur Patel" forKey:@"name"];
    [dictTemp1 setObject:@"Country : jds fjdsjd dda" forKey:@"country"];
    [dictTemp1 setObject:@"Desc : Snj djK SHBSB sndjns dsad mksa wrjiej jewiijweij fjwef fewuhewrwens dsad mksa dksmkdmskdmkdmkam dkmamdma wrjiej jewiijweij fjwef fewuhewrwens dsad mksa dksmkdmskdmkdmkam dkmamdma wrjiej jewiijweij fjwef fewuhewrwens dsad mksa dksmkdmskdmkdmkam dkmamdma wrjiej jewiijweij fjwef fewuhewrwens dsad mksa dksmkdmskdmkdmkam dkmamdma " forKey:@"desc"];
    [arrUser addObject:dictTemp1];
    
    NSMutableDictionary *dictTemp2 = [[NSMutableDictionary alloc]init];
    [dictTemp2 setObject:@"https://www.seeklogo.net/wp-content/uploads/2012/02/google-chrome-logo-vector.jpg" forKey:@"url"];
    [dictTemp2 setObject:@"Name : Ankur Patel" forKey:@"name"];
    [dictTemp2 setObject:@"Country : jds fjdsjd ddajds fjdsjd dda  jds fjdsjd ddajds fjdsjd dda  jds fjdsjd ddajds fjdsjd dda  jds fjdsjd ddajds fjdsjd dda  jds fjdsjd ddajds fjdsjd dda" forKey:@"country"];
    [dictTemp2 setObject:@"Desc : Snj djK SHBSB sndjbhfdhsbhds gdsgfgsg vfgdsv gfvgd sgfgdsfgvsgdv fgsvgfvgdsvfgvdsgfvgdsv skdpwqepqerewyt bcxnvbdfgyurwehqw;s ndbshdfygregwheihrpqwe bvbuygeyrg fywfydkdoqwhuqrhhwqehwq ecd vbhojriejwrjiej jewiijweij fjwef fewuhewrwens dsad mksa dksmkdmskdmkdmkam dkmamdma dkamd  dasdasd abd asd asd as da das dasd asd d sdasd sa d as wrjiej jewiijweij fjwef fewuhewrwens dsad mksa dksmkdmskdmkdmkam dkmamdma wrjiej jewiijweij fjwef fewuhewrwens dsad mksa dksmkdmskdmkdmkam dkmamdma wrjiej jewiijweij fjwef fewuhewrwens dsad mksa dksmkdmskdmkdmkam dkmamdma wrjiej jewiijweij fjwef fewuhewrwens dsad mksa dksmkdmskdmkdmkam dkmamdma " forKey:@"desc"];
    [arrUser addObject:dictTemp2];
    
    NSMutableDictionary *dictTemp3 = [[NSMutableDictionary alloc]init];
    [dictTemp3 setObject:@"http://searchengineland.com/figz/wp-content/seloads/2013/12/google-plus-logo.png" forKey:@"url"];
    [dictTemp3 setObject:@"Name : Anfdsfjds fdhs fvgsd vfgdsvgfv gsdvfgv sdv fsvgf vgsvdf vdsg fgds vfskur Patel" forKey:@"name"];
    [dictTemp3 setObject:@"Country : jwepqope" forKey:@"country"];
    [dictTemp3 setObject:@"Desc : Snj djK SHBdsfsfdSB sndjns dsad mksa dksmkdmskdmkdmkam dkmamdma dkamd  dasdasd abd asd asd as da das dasd asd d sdasd sa d as" forKey:@"desc"];
    [arrUser addObject:dictTemp3];
    
    NSMutableDictionary *dictTemp4 = [[NSMutableDictionary alloc]init];
    [dictTemp4 setObject:@"http://cdn.appstorm.net/web.appstorm.net/files/2010/04/Google-Earth-Logo-200x200.png" forKey:@"url"];
    [dictTemp4 setObject:@"Name : Ankur Patel" forKey:@"name"];
    [dictTemp4 setObject:@"Country : jds ff dsf ds f fdsfdsfdsfsfsf jdsjd dda" forKey:@"country"];
    [dictTemp4 setObject:@"Desc : Snj djK SHBSB sndjns dsad mksa" forKey:@"desc"];
    [arrUser addObject:dictTemp4];
    
    NSMutableDictionary *dictTemp5 = [[NSMutableDictionary alloc]init];
    [dictTemp5 setObject:@"http://www.technobuffalo.com/wp-content/uploads/2016/08/google-mini-game-200x200.jpg" forKey:@"url"];
    [dictTemp5 setObject:@"Name : Ankur Patel" forKey:@"name"];
    [dictTemp5 setObject:@"Country : jds fjdsjd dda  jds fjdsjd ddajds fjdsjd dda  jds fjdsjd ddajds fjdsjd dda  jds fjdsjd ddajds fjdsjd dda  jds fjdsjd ddajds fjdsjd dda  jds fjdsjd ddajds fjdsjd dda  jds fjdsjd ddajds fjdsjd dda" forKey:@"country"];
    [dictTemp5 setObject:@"Desc : Snj djK SHBSB sndjns dsad mksa dksmkdmskdmkdmkam dkmamdma dkamd  dasdasd abd asd asd as da das dasd asd d snjfds fds fdsfgsdgfvgdsvfgvdsgfvgdsvgfvdgsvf gdsvgfvdsvg fvdgs vfgvdsgfvgdsf dsf dsfds fdasd sa d as" forKey:@"desc"];
    [arrUser addObject:dictTemp5];
    
    [self.tblUser reloadData];
    
    [self.tblUser setNeedsLayout];
    [self.tblUser layoutIfNeeded];
    
    NSLog(@"tblUser : %f %f %f %f",self.tblUser.frame.origin.x,self.tblUser.frame.origin.y,self.tblUser.frame.size.width,self.tblUser.frame.size.height);
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

# pragma mark - Cell Setup


# pragma mark - UITableViewControllerDelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return arrUser.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    /*
    DynTableViewCell *cell = (DynTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"DynamicCell"];
    
    cell = nil;
    if (cell == nil) {
        cell = [[DynTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"DynamicCell"];
    }
    */
    
    DynTableViewCell *cell = (DynTableViewCell *)[tableView dequeueReusableCellWithIdentifier:@"DynamicCell" ];
    
    NSMutableDictionary *dictTemp = [arrUser objectAtIndex:indexPath.row];
    
    NSLog(@"dictTemp : %@",dictTemp);
    
    cell.lblUserName.text = [dictTemp objectForKey:@"name"];
    cell.lblUserName.numberOfLines = 0;
    cell.lblUserCountry.text = [dictTemp objectForKey:@"country"];
    cell.lblUserCountry.numberOfLines = 0;
    cell.lblUserDesc.text = [dictTemp objectForKey:@"desc"];
    cell.lblUserDesc.numberOfLines = 0;
    
//    if(indexPath.row % 2 == 0)
//    {
//        cell.lblUserDesc.text = @"";
//    }
    cell.constBtn2Height.constant = 35;
    cell.constLblDescBottom.constant = 10;
    if (indexPath.row == 0) {
        cell.btnVideoImage.hidden = YES;
        cell.constBtn2Height.constant = 0;
        cell.constLblDescBottom.constant = 0;
    }
    else if (indexPath.row == 1) {
        cell.lblUserDesc.text = @"";
        cell.constLblDescBottom.constant = 0;
        cell.lblUserDesc.numberOfLines = 0;
    }
    else if (indexPath.row ==3){
        cell.btnVideoImage.hidden = YES;
        cell.constBtn2Height.constant = 0;
        cell.lblUserDesc.text = @"";
        cell.lblUserDesc.numberOfLines = 0;
        cell.constLblDescBottom.constant = -10;
    }
    
    NSURL *URL1 = [NSURL URLWithString:[dictTemp objectForKey:@"url"]];
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:URL1];
    [NSURLConnection sendAsynchronousRequest:urlRequest queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
     {
         /*
          NSLog(@"response : %@ error : %@ username : %@",response,error,[dictTemp objectForKey:@"imageName"]);
          
          NSHTTPURLResponse *HTTPResponse = (NSHTTPURLResponse *)response;
          NSInteger strStatusCode = [HTTPResponse statusCode];
          NSLog(@"strStatusCode : %ld",(long)strStatusCode);
          */
         
         uint8_t c;
         [data getBytes:&c length:1];
         
         if(c == 0xFF || c == 0x89  || c == 0x47  || c == 0x49 || c == 0x4D )
         {
             
             NSLog(@"dddd");
             [cell.btnUserPic setBackgroundImage:[UIImage imageWithData:data] forState:UIControlStateNormal];
             [cell.btnUserPic setBackgroundImage:[UIImage imageWithData:data] forState:UIControlStateHighlighted];
         }
         else
         {
             NSLog(@"cccc");
             [cell.btnUserPic setBackgroundImage:[UIImage imageNamed:@"world-default.png"] forState:UIControlStateNormal];
             [cell.btnUserPic setBackgroundImage:[UIImage imageNamed:@"world-default.png"] forState:UIControlStateHighlighted];
         }
     }];
    
    return cell;
}


@end
