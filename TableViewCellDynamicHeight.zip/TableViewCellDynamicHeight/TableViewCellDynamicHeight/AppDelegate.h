//
//  AppDelegate.h
//  TableViewCellDynamicHeight
//
//  Created by Pro Start Me on 9/8/16.
//  Copyright © 2016 Pro Start Me. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

