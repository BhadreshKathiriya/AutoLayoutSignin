//
//  ViewController.h
//  TableViewCellDynamicHeight
//
//  Created by Pro Start Me on 9/8/16.
//  Copyright © 2016 Pro Start Me. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    NSMutableArray *arrUser;
}
@property (weak, nonatomic) IBOutlet UITableView *tblUser;

@end

