//
//  DynTableViewCell.h
//  TableViewCellDynamicHeight
//
//  Created by Pro Start Me on 9/8/16.
//  Copyright © 2016 Pro Start Me. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DynTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *btnUserPic;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *constBtn2Height;
@property (weak, nonatomic) IBOutlet UILabel *lblUserName;
@property (weak, nonatomic) IBOutlet UILabel *lblUserCountry;
@property (weak, nonatomic) IBOutlet UILabel *lblUserDesc;
@property (weak, nonatomic) IBOutlet UIButton *btnVideoImage;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *constLblDescBottom;

@end
